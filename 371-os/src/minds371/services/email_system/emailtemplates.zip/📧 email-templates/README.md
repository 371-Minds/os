# email-templates 2

React Email + Mautic templates

## Structure

- **templates/**:  - **components/**:  - **styles/**:  - **automation/**:  - **exports/**: 

## Last Updated

2025-06-23 07:22:05

---
*Part of the 371 Minds Ecosystem*
