import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface SocialMediaReportEmailProps {
  clientName?: string;
  reportPeriod?: string;
  totalFollowers?: number;
  followerGrowth?: number;
  totalEngagement?: number;
  engagementRate?: number;
  topPost?: string;
  topPlatform?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const SocialMediaReportEmail = ({
  clientName = 'Valued Client',
  reportPeriod = 'March 2024',
  totalFollowers = 12450,
  followerGrowth = 8.5,
  totalEngagement = 3280,
  engagementRate = 4.2,
  topPost = 'Behind-the-scenes product development video',
  topPlatform = 'Instagram',
}: SocialMediaReportEmailProps) => (
  <Html>
    <Head />
    <Preview>Your {reportPeriod} social media report - {followerGrowth}% growth achieved!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/rootlift-digital-logo.png`}
            width="160"
            height="40"
            alt="Rootlift Digital"
            style={logo}
          />
        </Section>
        
        <Section style={headerBanner}>
          <Text style={headerIcon}>📱</Text>
          <Heading style={h1}>Social Media Performance Report</Heading>
          <Text style={periodText}>{reportPeriod}</Text>
        </Section>

        <Text style={heroText}>
          Hi {clientName}, your social media presence continues to grow strong! This month brought 
          excellent engagement rates and meaningful follower growth across all platforms. 
          Here's a comprehensive breakdown of your social media performance.
        </Text>
        
        <Section style={overviewSection}>
          <Text style={overviewTitle}>Monthly Overview</Text>
          
          <Section style={overviewGrid}>
            <Section style={overviewCard}>
              <Text style={overviewIcon}>👥</Text>
              <Text style={overviewValue}>{totalFollowers.toLocaleString()}</Text>
              <Text style={overviewLabel}>Total Followers</Text>
              <Text style={overviewGrowth}>+{followerGrowth}% this month</Text>
            </Section>

            <Section style={overviewCard}>
              <Text style={overviewIcon}>❤️</Text>
              <Text style={overviewValue}>{totalEngagement.toLocaleString()}</Text>
              <Text style={overviewLabel}>Total Engagement</Text>
              <Text style={overviewGrowth}>+12.3% vs last month</Text>
            </Section>

            <Section style={overviewCard}>
              <Text style={overviewIcon}>📊</Text>
              <Text style={overviewValue}>{engagementRate}%</Text>
              <Text style={overviewLabel}>Avg. Engagement Rate</Text>
              <Text style={overviewGrowth}>Above industry avg</Text>
            </Section>

            <Section style={overviewCard}>
              <Text style={overviewIcon}>🏆</Text>
              <Text style={overviewValue}>{topPlatform}</Text>
              <Text style={overviewLabel}>Top Platform</Text>
              <Text style={overviewGrowth}>Best performing</Text>
            </Section>
          </Section>
        </Section>

        <Section style={platformSection}>
          <Text style={platformTitle}>Platform Performance Breakdown</Text>
          
          <Section style={platformItem}>
            <Section style={platformHeader}>
              <Text style={platformIcon}>📸</Text>
              <Text style={platformName}>Instagram</Text>
              <Text style={platformGrowth}>+12.5%</Text>
            </Section>
            <Text style={platformStats}>4,850 followers • 1,240 engagements • 5.1% rate</Text>
            <Text style={platformHighlight}>🏆 Top performing platform this month</Text>
          </Section>

          <Section style={platformItem}>
            <Section style={platformHeader}>
              <Text style={platformIcon}>📘</Text>
              <Text style={platformName}>Facebook</Text>
              <Text style={platformGrowth}>+6.8%</Text>
            </Section>
            <Text style={platformStats}>3,200 followers • 890 engagements • 3.8% rate</Text>
            <Text style={platformHighlight}>📈 Strong video content performance</Text>
          </Section>

          <Section style={platformItem}>
            <Section style={platformHeader}>
              <Text style={platformIcon}>💼</Text>
              <Text style={platformName}>LinkedIn</Text>
              <Text style={platformGrowth}>+15.2%</Text>
            </Section>
            <Text style={platformStats}>2,100 followers • 650 engagements • 4.5% rate</Text>
            <Text style={platformHighlight">🚀 Highest growth rate this month</Text>
          </Section>

          <Section style={platformItem}>
            <Section style={platformHeader}>
              <Text style={platformIcon}>🐦</Text>
              <Text style={platformName}>Twitter/X</Text>
              <Text style={platformGrowth}>+4.1%</Text>
            </Section>
            <Text style={platformStats}>2,300 followers • 500 engagements • 2.9% rate</Text>
            <Text style={platformHighlight}>💬 Great conversation starter posts</Text>
          </Section>
        </Section>

        <Section style={contentSection}>
          <Text style={contentTitle}>Top Performing Content</Text>
          
          <Section style={contentItem}>
            <Text style={contentIcon">🎥</Text>
            <div>
              <Text style={contentTitle}>"{topPost}"</Text>
              <Text style={contentStats}>2,450 likes • 180 comments • 95 shares</Text>
              <Text style={contentPlatform}>Instagram & Facebook</Text>
            </div>
          </Section>

          <Section style={contentItem}>
            <Text style={contentIcon}>💡</Text>
            <div>
              <Text style={contentTitle}>"5 Industry Trends to Watch in 2024"</Text>
              <Text style={contentStats}>1,890 likes • 145 comments • 78 shares</Text>
              <Text style={contentPlatform}>LinkedIn</Text>
            </div>
          </Section>

          <Section style={contentItem}>
            <Text style={contentIcon}>📊</Text>
            <div>
              <Text style={contentTitle}>"Monthly Business Insights Infographic"</Text>
              <Text style={contentStats}>1,650 likes • 92 comments • 156 shares</Text>
              <Text style={contentPlatform}>All Platforms</Text>
            </div>
          </Section>
        </Section>

        <Section style={audienceSection}>
          <Text style={audienceTitle}>Audience Insights</Text>
          
          <Section style={audienceGrid}>
            <Section style={audienceCard}>
              <Text style={audienceLabel}>Top Age Group</Text>
              <Text style={audienceValue}>25-34 years</Text>
              <Text style={audiencePercent}>42% of audience</Text>
            </Section>

            <Section style={audienceCard}>
              <Text style={audienceLabel}>Primary Location</Text>
              <Text style={audienceValue}>United States</Text>
              <Text style={audiencePercent}>68% of followers</Text>
            </Section>

            <Section style={audienceCard}>
              <Text style={audienceLabel}>Peak Activity</Text>
              <Text style={audienceValue}>Tue-Thu 2-4 PM</Text>
              <Text style={audiencePercent">Best posting time</Text>
            </Section>

            <Section style={audienceCard}>
              <Text style={audienceLabel}>Gender Split</Text>
              <Text style={audienceValue}>52% Female</Text>
              <Text style={audiencePercent}>48% Male</Text>
            </Section>
          </Section>
        </Section>

        <Section style={buttonContainer}>
          <Button style={button} href="https://rootliftdigital.com/social-report">
            View Detailed Report
          </Button>
        </Section>

        <Section style={strategiesSection}>
          <Text style={strategiesTitle}>Winning Strategies This Month</Text>
          
          <Section style={strategyItem}>
            <Text style={strategyIcon}>🎬</Text>
            <Text style={strategyText}>Behind-the-scenes content generated 35% higher engagement</Text>
          </Section>

          <Section style={strategyItem}>
            <Text style={strategyIcon}>💬</Text>
            <Text style={strategyText">Interactive polls and Q&As boosted audience participation by 28%</Text>
          </Section>

          <Section style={strategyItem}>
            <Text style={strategyIcon}>📅</Text>
            <Text style={strategyText">Consistent posting schedule improved reach by 22%</Text>
          </Section>

          <Section style={strategyItem}>
            <Text style={strategyIcon">🤝</Text>
            <Text style={strategyText">User-generated content campaigns increased brand mentions by 45%</Text>
          </Section>
        </Section>

        <Section style={nextMonthSection}>
          <Text style={nextMonthTitle}>Next Month's Focus Areas</Text>
          <Text style={nextMonthItem}>🎯 Launch spring product campaign across all platforms</Text>
          <Text style={nextMonthItem">📹 Increase video content production by 40%</Text>
          <Text style={nextMonthItem">🤝 Partner with 3 micro-influencers in your industry</Text>
          <Text style={nextMonthItem">📊 A/B test optimal posting times for each platform</Text>
          <Text style={nextMonthItem">💡 Develop thought leadership content series</Text>
        </Section>

        <Text style={text}>
          Want to discuss these results and plan next month's strategy? Let's schedule a{' '}
          <Link href="https://calendly.com/rootliftdigital/social-strategy" style={link}>
            social media strategy call
          </Link>.
        </Text>

        <Text style={text}>
          Questions about your social media performance?{' '}
          <Link href="mailto:social@rootliftdigital.com" style={link}>
            social@rootliftdigital.com
          </Link>
        </Text>

        <Text style={text}>
          Keep up the great social momentum!
          <br />
          The Rootlift Digital Social Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default SocialMediaReportEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
  textAlign: 'center' as const,
};

const logo = {
  margin: '0 auto',
};

const headerBanner = {
  textAlign: 'center' as const,
  margin: '40px 0 20px 0',
  padding: '24px',
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  border: '1px solid #f59e0b',
};

const headerIcon = {
  fontSize: '48px',
  margin: '0 0 16px 0',
};

const h1 = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
  padding: '0',
};

const periodText = {
  color: '#6b7280',
  fontSize: '16px',
  fontWeight: '500',
  margin: '0',
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '24px 0',
};

const overviewSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  border: '1px solid #fecaca',
};

const overviewTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 24px 0',
  textAlign: 'center' as const,
};

const overviewGrid = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '16px',
};

const overviewCard = {
  textAlign: 'center' as const,
  padding: '16px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const overviewIcon = {
  fontSize: '24px',
  margin: '0 0 8px 0',
};

const overviewValue = {
  color: '#e11d48',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const overviewLabel = {
  color: '#1f2937',
  fontSize: '12px',
  fontWeight: '600',
  margin: '0 0 4px 0',
};

const overviewGrowth = {
  color: '#059669',
  fontSize: '10px',
  fontWeight: '500',
  margin: '0',
};

const platformSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const platformTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const platformItem = {
  margin: '16px 0',
  padding: '16px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const platformHeader = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  margin: '0 0 8px 0',
};

const platformIcon = {
  fontSize: '20px',
  marginRight: '8px',
};

const platformName = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  flex: 1,
};

const platformGrowth = {
  color: '#059669',
  fontSize: '14px',
  fontWeight: 'bold',
};

const platformStats = {
  color: '#6b7280',
  fontSize: '13px',
  margin: '4px 0',
};

const platformHighlight = {
  color: '#7c3aed',
  fontSize: '12px',
  fontWeight: '500',
  margin: '4px 0 0 0',
};

const contentSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#ecfdf5',
  borderRadius: '8px',
  border: '1px solid #10b981',
};

const contentTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const contentItem = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const contentIcon = {
  fontSize: '20px',
  marginRight: '12px',
  flexShrink: 0,
};

const contentStats = {
  color: '#6b7280',
  fontSize: '12px',
  margin: '4px 0',
};

const contentPlatform = {
  color: '#7c3aed',
  fontSize: '11px',
  fontWeight: '500',
  margin: '4px 0 0 0',
};

const audienceSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f0f9ff',
  borderRadius: '8px',
  border: '1px solid #0ea5e9',
};

const audienceTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const audienceGrid = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '12px',
};

const audienceCard = {
  textAlign: 'center' as const,
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '4px',
};

const audienceLabel = {
  color: '#6b7280',
  fontSize: '11px',
  fontWeight: '500',
  margin: '0 0 4px 0',
};

const audienceValue = {
  color: '#1f2937',
  fontSize: '13px',
  fontWeight: 'bold',
  margin: '0 0 2px 0',
};

const audiencePercent = {
  color: '#0ea5e9',
  fontSize: '10px',
  fontWeight: '500',
  margin: '0',
};

const buttonContainer = {
  margin: '32px auto',
  width: 'auto',
  textAlign: 'center' as const,
};

const button = {
  backgroundColor: '#e11d48',
  borderRadius: '6px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '12px 24px',
};

const strategiesSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  border: '1px solid #f59e0b',
};

const strategiesTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const strategyItem = {
  display: 'flex',
  alignItems: 'center',
  margin: '8px 0',
  padding: '8px',
};

const strategyIcon = {
  fontSize: '16px',
  marginRight: '12px',
};

const strategyText = {
  color: '#374151',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const nextMonthSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f0fdf4',
  borderRadius: '8px',
  border: '1px solid #22c55e',
};

const nextMonthTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
};

const nextMonthItem = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '8px 0',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#e11d48',
  textDecoration: 'underline',
};