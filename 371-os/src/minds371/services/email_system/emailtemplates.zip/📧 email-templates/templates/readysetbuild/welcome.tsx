import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface ReadySetBuildWelcomeEmailProps {
  userFirstName?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const ReadySetBuildWelcomeEmail = ({
  userFirstName = 'Developer',
}: ReadySetBuildWelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to ReadySetBuild - Your deployment journey starts now!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/readysetbuild-logo.png`}
            width="120"
            height="36"
            alt="ReadySetBuild"
            style={logo}
          />
        </Section>
        <Heading style={h1}>Welcome to ReadySetBuild, {userFirstName}!</Heading>
        <Text style={heroText}>
          You're now part of a platform that makes deployment as easy as a single click.
          Let's get you started on your journey to effortless application deployment.
        </Text>
        
        <Section style={codeBox}>
          <Text style={confirmationCodeText}>
            🚀 Your deployment platform is ready to use
          </Text>
        </Section>

        <Text style={text}>
          Here's what you can do next:
        </Text>
        
        <Section style={buttonContainer}>
          <Button style={button} href="https://readysetbuild.com/dashboard">
            Access Your Dashboard
          </Button>
        </Section>

        <Section style={featuresSection}>
          <Text style={featuresTitle}>What you get with ReadySetBuild:</Text>
          <Text style={featureItem}>✅ One-click deployments</Text>
          <Text style={featureItem}>✅ Automatic scaling</Text>
          <Text style={featureItem}>✅ Built-in monitoring</Text>
          <Text style={featureItem}>✅ 24/7 support</Text>
        </Section>

        <Text style={text}>
          Need help getting started? Check out our{' '}
          <Link href="https://docs.readysetbuild.com" style={link}>
            documentation
          </Link>{' '}
          or reach out to our support team.
        </Text>

        <Text style={text}>
          Happy deploying!
          <br />
          The ReadySetBuild Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default ReadySetBuildWelcomeEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
};

const logo = {
  margin: '0 auto',
};

const h1 = {
  color: '#1f2937',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '40px 0',
  padding: '0',
  textAlign: 'center' as const,
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '16px 0',
  textAlign: 'center' as const,
};

const codeBox = {
  background: 'rgb(245, 244, 245)',
  borderRadius: '4px',
  margin: '16px auto 14px',
  verticalAlign: 'middle',
  width: '280px',
};

const confirmationCodeText = {
  color: '#000',
  display: 'inline-block',
  fontFamily: 'monospace',
  fontSize: '32px',
  fontWeight: 700,
  letterSpacing: '6px',
  lineHeight: '40px',
  paddingBottom: '8px',
  paddingTop: '8px',
  margin: '0 auto',
  width: '100%',
  textAlign: 'center' as const,
};

const buttonContainer = {
  margin: '27px auto',
  width: 'auto',
};

const button = {
  backgroundColor: '#3b82f6',
  borderRadius: '3px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '15px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'block',
  padding: '11px 23px',
};

const featuresSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f9fafb',
  borderRadius: '8px',
};

const featuresTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 12px 0',
};

const featureItem = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '4px 0',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#3b82f6',
  textDecoration: 'underline',
};