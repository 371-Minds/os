import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface CampaignResultsEmailProps {
  clientName?: string;
  campaignName?: string;
  campaignPeriod?: string;
  impressions?: number;
  clicks?: number;
  conversions?: number;
  roi?: number;
  topPerformingChannel?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const CampaignResultsEmail = ({
  clientName = 'Valued Client',
  campaignName = 'Q4 Marketing Campaign',
  campaignPeriod = 'Last 30 Days',
  impressions = 125000,
  clicks = 3250,
  conversions = 187,
  roi = 285,
  topPerformingChannel = 'Google Ads',
}: CampaignResultsEmailProps) => (
  <Html>
    <Head />
    <Preview>Your {campaignName} results are in - Outstanding performance!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/rootlift-digital-logo.png`}
            width="160"
            height="40"
            alt="Rootlift Digital"
            style={logo}
          />
        </Section>
        
        <Section style={headerBanner}>
          <Text style={headerIcon}>📊</Text>
          <Heading style={h1}>Campaign Results Report</Heading>
          <Text style={campaignTitle}>{campaignName}</Text>
          <Text style={periodText}>{campaignPeriod}</Text>
        </Section>

        <Text style={heroText}>
          Hi {clientName}, we're excited to share the outstanding results from your recent marketing campaign. 
          Your investment in digital marketing is paying off with impressive performance across all key metrics.
        </Text>
        
        <Section style={metricsSection}>
          <Text style={metricsTitle}>Key Performance Metrics</Text>
          
          <Section style={metricsGrid}>
            <Section style={metricCard}>
              <Text style={metricIcon}>👁️</Text>
              <Text style={metricValue}>{impressions.toLocaleString()}</Text>
              <Text style={metricLabel}>Total Impressions</Text>
            </Section>

            <Section style={metricCard}>
              <Text style={metricIcon}>🖱️</Text>
              <Text style={metricValue}>{clicks.toLocaleString()}</Text>
              <Text style={metricLabel}>Clicks Generated</Text>
            </Section>

            <Section style={metricCard}>
              <Text style={metricIcon}>🎯</Text>
              <Text style={metricValue}>{conversions}</Text>
              <Text style={metricLabel}>Conversions</Text>
            </Section>

            <Section style={metricCard}>
              <Text style={metricIcon}>💰</Text>
              <Text style={metricValue}>{roi}%</Text>
              <Text style={metricLabel}>ROI</Text>
            </Section>
          </Section>
        </Section>

        <Section style={highlightsSection}>
          <Text style={highlightsTitle}>Campaign Highlights</Text>
          
          <Section style={highlightItem}>
            <Text style={highlightIcon}>🏆</Text>
            <div>
              <Text style={highlightTitle}>Top Performing Channel</Text>
              <Text style={highlightDesc}>{topPerformingChannel} delivered {Math.round((conversions * 0.4))} conversions</Text>
            </div>
          </Section>

          <Section style={highlightItem}>
            <Text style={highlightIcon}>📈</Text>
            <div>
              <Text style={highlightTitle}>Click-Through Rate</Text>
              <Text style={highlightDesc}>{((clicks / impressions) * 100).toFixed(2)}% CTR - 45% above industry average</Text>
            </div>
          </Section>

          <Section style={highlightItem}>
            <Text style={highlightIcon}>🎯</Text>
            <div>
              <Text style={highlightTitle}>Conversion Rate</Text>
              <Text style={highlightDesc}>{((conversions / clicks) * 100).toFixed(2)}% conversion rate - exceptional performance</Text>
            </div>
          </Section>

          <Section style={highlightItem}>
            <Text style={highlightIcon}>💡</Text>
            <div>
              <Text style={highlightTitle}>Cost Efficiency</Text>
              <Text style={highlightDesc}>25% reduction in cost-per-acquisition vs. previous campaign</Text>
            </div>
          </Section>
        </Section>

        <Section style={channelBreakdownSection}>
          <Text style={channelTitle}>Channel Performance Breakdown</Text>
          
          <Section style={channelItem}>
            <Text style={channelName}>Google Ads</Text>
            <Text style={channelPerformance}>40% of conversions • $2.15 CPA</Text>
          </Section>

          <Section style={channelItem}>
            <Text style={channelName}>Facebook/Instagram</Text>
            <Text style={channelPerformance}>28% of conversions • $2.85 CPA</Text>
          </Section>

          <Section style={channelItem}>
            <Text style={channelName}>LinkedIn Ads</Text>
            <Text style={channelPerformance}>18% of conversions • $4.20 CPA</Text>
          </Section>

          <Section style={channelItem}>
            <Text style={channelName}>Organic Search</Text>
            <Text style={channelPerformance}>14% of conversions • $0.00 CPA</Text>
          </Section>
        </Section>

        <Section style={buttonContainer}>
          <Button style={button} href="https://rootliftdigital.com/detailed-report">
            View Full Report
          </Button>
        </Section>

        <Section style={nextStepsSection}>
          <Text style={nextStepsTitle}>Recommended Next Steps:</Text>
          <Text style={nextStep}>📊 Scale successful ad sets with increased budget allocation</Text>
          <Text style={nextStep}>🎯 A/B test new creative variations for top-performing campaigns</Text>
          <Text style={nextStep}>🔄 Implement retargeting campaigns for website visitors</Text>
          <Text style={nextStep}>📈 Expand to additional high-potential keywords and audiences</Text>
        </Section>

        <Text style={text}>
          Want to discuss these results in detail? Let's schedule a{' '}
          <Link href="https://calendly.com/rootliftdigital/results-review" style={link}>
            strategy review call
          </Link>{' '}
          to plan your next campaign.
        </Text>

        <Text style={text}>
          Questions about your campaign performance?{' '}
          <Link href="mailto:results@rootliftdigital.com" style={link}>
            results@rootliftdigital.com
          </Link>
        </Text>

        <Text style={text}>
          Celebrating your success!
          <br />
          The Rootlift Digital Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default CampaignResultsEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
  textAlign: 'center' as const,
};

const logo = {
  margin: '0 auto',
};

const headerBanner = {
  textAlign: 'center' as const,
  margin: '40px 0 20px 0',
  padding: '24px',
  backgroundColor: '#f0f9ff',
  borderRadius: '8px',
  border: '1px solid #0ea5e9',
};

const headerIcon = {
  fontSize: '48px',
  margin: '0 0 16px 0',
};

const h1 = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
  padding: '0',
};

const campaignTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: '600',
  margin: '0 0 4px 0',
};

const periodText = {
  color: '#6b7280',
  fontSize: '14px',
  margin: '0',
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '24px 0',
};

const metricsSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  border: '1px solid #fecaca',
};

const metricsTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 24px 0',
  textAlign: 'center' as const,
};

const metricsGrid = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '16px',
};

const metricCard = {
  textAlign: 'center' as const,
  padding: '16px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const metricIcon = {
  fontSize: '24px',
  margin: '0 0 8px 0',
};

const metricValue = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const metricLabel = {
  color: '#6b7280',
  fontSize: '12px',
  fontWeight: '500',
  margin: '0',
};

const highlightsSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const highlightsTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const highlightItem = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const highlightIcon = {
  fontSize: '20px',
  marginRight: '12px',
  flexShrink: 0,
};

const highlightTitle = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const highlightDesc = {
  color: '#6b7280',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const channelBreakdownSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#ecfdf5',
  borderRadius: '8px',
  border: '1px solid #10b981',
};

const channelTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const channelItem = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  margin: '8px 0',
  padding: '8px 12px',
  backgroundColor: '#ffffff',
  borderRadius: '4px',
};

const channelName = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: '600',
  margin: '0',
};

const channelPerformance = {
  color: '#059669',
  fontSize: '12px',
  fontWeight: '500',
  margin: '0',
};

const buttonContainer = {
  margin: '32px auto',
  width: 'auto',
  textAlign: 'center' as const,
};

const button = {
  backgroundColor: '#e11d48',
  borderRadius: '6px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '12px 24px',
};

const nextStepsSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  border: '1px solid #f59e0b',
};

const nextStepsTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
};

const nextStep = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '8px 0',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#e11d48',
  textDecoration: 'underline',
};