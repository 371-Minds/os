import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface ClientReferralRequestEmailProps {
  clientName?: string;
  projectSuccess?: string;
  monthsWorking?: number;
  keyAchievement?: string;
  referralIncentive?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const ClientReferralRequestEmail = ({
  clientName = 'Valued Client',
  projectSuccess = 'increased your online visibility by 150%',
  monthsWorking = 6,
  keyAchievement = '40% increase in qualified leads',
  referralIncentive = '$500 credit toward your next campaign',
}: ClientReferralRequestEmailProps) => (
  <Html>
    <Head />
    <Preview>Help us grow - Your referrals mean the world to us!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/rootlift-digital-logo.png`}
            width="160"
            height="40"
            alt="Rootlift Digital"
            style={logo}
          />
        </Section>
        
        <Section style={headerBanner}>
          <Text style={headerIcon}>🤝</Text>
          <Heading style={h1}>We'd Love Your Help!</Heading>
          <Text style={subheading}>Refer a business and earn rewards</Text>
        </Section>

        <Text style={heroText}>
          Hi {clientName}, it's been an incredible {monthsWorking} months working together! 
          We've {projectSuccess} and achieved {keyAchievement}. Your success is our greatest 
          achievement, and we're so proud of what we've accomplished together.
        </Text>
        
        <Section style={successSection}>
          <Text style={successTitle}>Your Success Story</Text>
          
          <Section style={successItem}>
            <Text style={successIcon}>📈</Text>
            <div>
              <Text style={successMetric}>{keyAchievement}</Text>
              <Text style={successDesc}>Measurable business growth</Text>
            </div>
          </Section>

          <Section style={successItem}>
            <Text style={successIcon}>🎯</Text>
            <div>
              <Text style={successMetric}>ROI-focused campaigns</Text>
              <Text style={successDesc}>Every dollar working harder for you</Text>
            </div>
          </Section>

          <Section style={successItem}>
            <Text style={successIcon}>🚀</Text>
            <div>
              <Text style={successMetric}>Strategic partnership</Text>
              <Text style={successDesc}>Dedicated team committed to your growth</Text>
            </div>
          </Section>
        </Section>

        <Section style={referralSection}>
          <Text style={referralTitle}>Know Someone Who Could Benefit?</Text>
          <Text style={referralText}>
            If you know another business owner who could use our help with digital marketing, 
            we'd be honored to work with them. Your referral is the highest compliment we can receive.
          </Text>
          
          <Section style={idealClientSection}>
            <Text style={idealClientTitle">Perfect Referral Candidates:</Text>
            
            <Section style={clientType}>
              <Text style={clientIcon">🏢</Text>
              <Text style={clientDesc">Small to medium businesses ready to scale</Text>
            </Section>

            <Section style={clientType}>
              <Text style={clientIcon">💼</Text>
              <Text style={clientDesc">Service-based companies needing more leads</Text>
            </Section>

            <Section style={clientType}>
              <Text style={clientIcon">🛍️</Text>
              <Text style={clientDesc">E-commerce brands wanting to increase sales</Text>
            </Section>

            <Section style={clientType}>
              <Text style={clientIcon">🎯</Text>
              <Text style={clientDesc">Companies struggling with their current marketing</Text>
            </Section>
          </Section>
        </Section>

        <Section style={incentiveSection}>
          <Text style={incentiveTitle}>Our Thank You to You</Text>
          <Text style={incentiveText}>
            When you refer a business that becomes our client, you'll receive:
          </Text>
          
          <Section style={rewardCard}>
            <Text style={rewardIcon}>💰</Text>
            <Text style={rewardTitle}>{referralIncentive}</Text>
            <Text style={rewardDesc}>Applied to your account once they sign up</Text>
          </Section>

          <Section style={bonusRewards}>
            <Text style={bonusTitle">Plus Additional Benefits:</Text>
            <Text style={bonusItem">🎁 Priority support for your campaigns</Text>
            <Text style={bonusItem">📊 Complimentary quarterly strategy review</Text>
            <Text style={bonusItem">🏆 Recognition in our client success stories</Text>
          </Section>
        </Section>

        <Section style={buttonContainer}>
          <Button style={button} href="https://rootliftdigital.com/refer">
            Refer a Business
          </Button>
        </Section>

        <Section style={processSection}>
          <Text style={processTitle}>How It Works</Text>
          
          <Section style={processStep}>
            <Text style={stepNumber}>1</Text>
            <div>
              <Text style={stepTitle}>Share Their Info</Text>
              <Text style={stepDesc">Use our simple referral form or email us directly</Text>
            </div>
          </Section>

          <Section style={processStep}>
            <Text style={stepNumber}>2</Text>
            <div>
              <Text style={stepTitle">We Reach Out</Text>
              <Text style={stepDesc">We'll contact them with a personalized approach</Text>
            </div>
          </Section>

          <Section style={processStep}>
            <Text style={stepNumber}>3</Text>
            <div>
              <Text style={stepTitle">You Get Rewarded</Text>
              <Text style={stepDesc">Receive your credit when they become a client</Text>
            </div>
          </Section>
        </Section>

        <Section style={testimonialSection}>
          <Text style={testimonialTitle}>What Our Referred Clients Say</Text>
          <Text style={testimonialQuote}>
            "The referral from our business partner was the best recommendation we've ever received. 
            Rootlift Digital transformed our online presence and doubled our leads in just 4 months!"
          </Text>
          <Text style={testimonialAuthor">- Sarah M., Referred Client</Text>
        </Section>

        <Section style={easyReferralSection}>
          <Text style={easyReferralTitle">Make a Referral Right Now</Text>
          <Text style={easyReferralText}>
            Simply reply to this email with:
          </Text>
          <Text style={referralInfo">• Business name and contact person</Text>
          <Text style={referralInfo">• Their email address or phone number</Text>
          <Text style={referralInfo">• Brief description of their business</Text>
          <Text style={referralInfo">• Why you think we'd be a good fit</Text>
        </Section>

        <Text style={text}>
          Have questions about our referral program? Check out our{' '}
          <Link href="https://rootliftdigital.com/referral-program" style={link}>
            referral program details
          </Link>{' '}
          or reach out directly.
        </Text>

        <Text style={text}>
          Ready to help a fellow business owner succeed?{' '}
          <Link href="mailto:referrals@rootliftdigital.com" style={link}>
            referrals@rootliftdigital.com
          </Link>
        </Text>

        <Text style={text}>
          Thank you for being an amazing client and partner!
          <br />
          The Rootlift Digital Team
        </Text>

        <Section style={footerNote}>
          <Text style={footerText}>
            P.S. There's no limit to how many businesses you can refer. 
            The more you share, the more you earn!
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
);

export default ClientReferralRequestEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
  textAlign: 'center' as const,
};

const logo = {
  margin: '0 auto',
};

const headerBanner = {
  textAlign: 'center' as const,
  margin: '40px 0 20px 0',
  padding: '24px',
  backgroundColor: '#ecfdf5',
  borderRadius: '8px',
  border: '1px solid #10b981',
};

const headerIcon = {
  fontSize: '48px',
  margin: '0 0 16px 0',
};

const h1 = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
  padding: '0',
};

const subheading = {
  color: '#6b7280',
  fontSize: '16px',
  fontWeight: '500',
  margin: '0',
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '24px 0',
};

const successSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  border: '1px solid #fecaca',
};

const successTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const successItem = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const successIcon = {
  fontSize: '20px',
  marginRight: '12px',
  flexShrink: 0,
};

const successMetric = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const successDesc = {
  color: '#6b7280',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const referralSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const referralTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const referralText = {
  color: '#374151',
  fontSize: '15px',
  lineHeight: '22px',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const idealClientSection = {
  margin: '20px 0 0 0',
};

const idealClientTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const clientType = {
  display: 'flex',
  alignItems: 'center',
  margin: '8px 0',
  padding: '8px 12px',
  backgroundColor: '#ffffff',
  borderRadius: '4px',
};

const clientIcon = {
  fontSize: '16px',
  marginRight: '12px',
};

const clientDesc = {
  color: '#374151',
  fontSize: '14px',
  margin: '0',
};

const incentiveSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  border: '1px solid #f59e0b',
  textAlign: 'center' as const,
};

const incentiveTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 12px 0',
};

const incentiveText = {
  color: '#374151',
  fontSize: '15px',
  margin: '0 0 20px 0',
};

const rewardCard = {
  padding: '20px',
  backgroundColor: '#ffffff',
  borderRadius: '8px',
  border: '2px solid #f59e0b',
  margin: '0 0 20px 0',
};

const rewardIcon = {
  fontSize: '32px',
  margin: '0 0 8px 0',
};

const rewardTitle = {
  color: '#e11d48',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const rewardDesc = {
  color: '#6b7280',
  fontSize: '13px',
  margin: '0',
};

const bonusRewards = {
  textAlign: 'left' as const,
};

const bonusTitle = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 12px 0',
};

const bonusItem = {
  color: '#374151',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '6px 0',
};

const buttonContainer = {
  margin: '32px auto',
  width: 'auto',
  textAlign: 'center' as const,
};

const button = {
  backgroundColor: '#e11d48',
  borderRadius: '6px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '12px 24px',
};

const processSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f0f9ff',
  borderRadius: '8px',
  border: '1px solid #0ea5e9',
};

const processTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const processStep = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const stepNumber = {
  backgroundColor: '#e11d48',
  color: '#ffffff',
  fontSize: '14px',
  fontWeight: 'bold',
  width: '24px',
  height: '24px',
  borderRadius: '50%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginRight: '12px',
  flexShrink: 0,
};

const stepTitle = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const stepDesc = {
  color: '#6b7280',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const testimonialSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f0fdf4',
  borderRadius: '8px',
  border: '1px solid #22c55e',
  textAlign: 'center' as const,
};

const testimonialTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
};

const testimonialQuote = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  fontStyle: 'italic',
  margin: '0 0 12px 0',
};

const testimonialAuthor = {
  color: '#6b7280',
  fontSize: '12px',
  fontWeight: '500',
  margin: '0',
};

const easyReferralSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const easyReferralTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 12px 0',
  textAlign: 'center' as const,
};

const easyReferralText = {
  color: '#374151',
  fontSize: '14px',
  margin: '0 0 12px 0',
  textAlign: 'center' as const,
};

const referralInfo = {
  color: '#374151',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '6px 0',
  paddingLeft: '16px',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#e11d48',
  textDecoration: 'underline',
};

const footerNote = {
  margin: '32px 0 0 0',
  padding: '16px',
  backgroundColor: '#fef3c7',
  borderRadius: '6px',
  textAlign: 'center' as const,
};

const footerText = {
  color: '#92400e',
  fontSize: '13px',
  fontWeight: '500',
  margin: '0',
};