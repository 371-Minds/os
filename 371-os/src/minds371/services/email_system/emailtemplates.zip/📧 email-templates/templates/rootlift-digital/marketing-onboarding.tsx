import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface MarketingOnboardingEmailProps {
  userFirstName?: string;
  companyName?: string;
  industryType?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const MarketingOnboardingEmail = ({
  userFirstName = 'Partner',
  companyName = 'Your Company',
  industryType = 'your industry',
}: MarketingOnboardingEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to Rootlift Digital - Your marketing transformation starts now!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/rootlift-digital-logo.png`}
            width="160"
            height="40"
            alt="Rootlift Digital"
            style={logo}
          />
        </Section>
        
        <Section style={welcomeBanner}>
          <Text style={welcomeIcon}>🚀</Text>
          <Heading style={h1}>Welcome to Rootlift Digital, {userFirstName}!</Heading>
        </Section>

        <Text style={heroText}>
          We're thrilled to partner with {companyName} on your digital marketing journey. 
          Our team specializes in elevating businesses in {industryType} through strategic, 
          data-driven marketing solutions that deliver real results.
        </Text>
        
        <Section style={onboardingSection}>
          <Text style={sectionTitle}>Your Onboarding Journey:</Text>
          
          <Section style={stepGroup}>
            <Text style={stepIcon}>📋</Text>
            <div>
              <Text style={stepTitle}>Discovery & Strategy Session</Text>
              <Text style={stepDesc}>Deep dive into your business goals, target audience, and competitive landscape</Text>
            </div>
          </Section>

          <Section style={stepGroup}>
            <Text style={stepIcon}>🎯</Text>
            <div>
              <Text style={stepTitle}>Custom Marketing Plan</Text>
              <Text style={stepDesc}>Tailored strategy covering SEO, content, social media, and paid advertising</Text>
            </div>
          </Section>

          <Section style={stepGroup}>
            <Text style={stepIcon}>⚙️</Text>
            <div>
              <Text style={stepTitle}>Implementation & Setup</Text>
              <Text style={stepDesc}>Launch campaigns, set up tracking, and establish reporting systems</Text>
            </div>
          </Section>

          <Section style={stepGroup}>
            <Text style={stepIcon}>📈</Text>
            <div>
              <Text style={stepTitle}>Monitor & Optimize</Text>
              <Text style={stepDesc}>Continuous performance tracking and strategy refinement</Text>
            </div>
          </Section>
        </Section>

        <Section style={servicesSection}>
          <Text style={servicesTitle}>Our Core Services for {companyName}:</Text>
          
          <Section style={serviceItem}>
            <Text style={serviceIcon}>🔍</Text>
            <Text style={serviceName}>SEO & Content Strategy</Text>
          </Section>

          <Section style={serviceItem}>
            <Text style={serviceIcon}>📱</Text>
            <Text style={serviceName}>Social Media Management</Text>
          </Section>

          <Section style={serviceItem}>
            <Text style={serviceIcon}>💰</Text>
            <Text style={serviceName}>Paid Advertising (Google, Facebook, LinkedIn)</Text>
          </Section>

          <Section style={serviceItem}>
            <Text style={serviceIcon}>📊</Text>
            <Text style={serviceName}>Analytics & Performance Reporting</Text>
          </Section>

          <Section style={serviceItem}>
            <Text style={serviceIcon}>🎨</Text>
            <Text style={serviceName}>Brand Development & Creative</Text>
          </Section>
        </Section>

        <Section style={buttonContainer}>
          <Button style={button} href="https://rootliftdigital.com/onboarding">
            Start Your Strategy Session
          </Button>
        </Section>

        <Section style={nextStepsSection}>
          <Text style={nextStepsTitle}>What Happens Next:</Text>
          <Text style={nextStep}>1. 📅 Schedule your discovery call within 48 hours</Text>
          <Text style={nextStep}>2. 📝 Complete our client questionnaire</Text>
          <Text style={nextStep}>3. 🎯 Receive your custom marketing strategy</Text>
          <Text style={nextStep}>4. 🚀 Launch your first campaigns</Text>
        </Section>

        <Text style={text}>
          Questions about the process? Check out our{' '}
          <Link href="https://rootliftdigital.com/onboarding-guide" style={link}>
            onboarding guide
          </Link>{' '}
          or reach out directly.
        </Text>

        <Text style={text}>
          Ready to accelerate your growth? Let's get started:{' '}
          <Link href="mailto:hello@rootliftdigital.com" style={link}>
            hello@rootliftdigital.com
          </Link>
        </Text>

        <Text style={text}>
          Excited to work with you!
          <br />
          The Rootlift Digital Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default MarketingOnboardingEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
  textAlign: 'center' as const,
};

const logo = {
  margin: '0 auto',
};

const welcomeBanner = {
  textAlign: 'center' as const,
  margin: '40px 0 20px 0',
};

const welcomeIcon = {
  fontSize: '48px',
  margin: '0 0 16px 0',
};

const h1 = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0',
  padding: '0',
  textAlign: 'center' as const,
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '24px 0',
  textAlign: 'center' as const,
};

const onboardingSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  border: '1px solid #fecaca',
};

const sectionTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 24px 0',
  textAlign: 'center' as const,
};

const stepGroup = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const stepIcon = {
  fontSize: '24px',
  marginRight: '12px',
  flexShrink: 0,
};

const stepTitle = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const stepDesc = {
  color: '#6b7280',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const servicesSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const servicesTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const serviceItem = {
  display: 'flex',
  alignItems: 'center',
  margin: '8px 0',
  padding: '8px',
};

const serviceIcon = {
  fontSize: '20px',
  marginRight: '12px',
};

const serviceName = {
  color: '#374151',
  fontSize: '14px',
  fontWeight: '500',
  margin: '0',
};

const buttonContainer = {
  margin: '32px auto',
  width: 'auto',
  textAlign: 'center' as const,
};

const button = {
  backgroundColor: '#e11d48',
  borderRadius: '6px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '12px 24px',
};

const nextStepsSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#ecfdf5',
  borderRadius: '8px',
  border: '1px solid #10b981',
};

const nextStepsTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
};

const nextStep = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '8px 0',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#e11d48',
  textDecoration: 'underline',
};