import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components';
import * as React from 'react';

interface SEOAuditCompleteEmailProps {
  clientName?: string;
  websiteUrl?: string;
  overallScore?: number;
  criticalIssues?: number;
  warningIssues?: number;
  opportunitiesFound?: number;
  topKeywordOpportunity?: string;
}

const baseUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : '';

export const SEOAuditCompleteEmail = ({
  clientName = 'Valued Client',
  websiteUrl = 'yourwebsite.com',
  overallScore = 72,
  criticalIssues = 8,
  warningIssues = 15,
  opportunitiesFound = 23,
  topKeywordOpportunity = 'digital marketing services',
}: SEOAuditCompleteEmailProps) => (
  <Html>
    <Head />
    <Preview>Your SEO audit is complete - {opportunitiesFound} optimization opportunities discovered!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={logoContainer}>
          <Img
            src={`${baseUrl}/static/rootlift-digital-logo.png`}
            width="160"
            height="40"
            alt="Rootlift Digital"
            style={logo}
          />
        </Section>
        
        <Section style={headerBanner}>
          <Text style={headerIcon}>🔍</Text>
          <Heading style={h1}>SEO Audit Complete</Heading>
          <Text style={websiteText}>{websiteUrl}</Text>
        </Section>

        <Text style={heroText}>
          Hi {clientName}, your comprehensive SEO audit is now complete! We've analyzed every aspect 
          of your website's search engine optimization and discovered significant opportunities to 
          boost your organic visibility and traffic.
        </Text>
        
        <Section style={scoreSection}>
          <Text style={scoreTitle}>Overall SEO Health Score</Text>
          <Section style={scoreDisplay}>
            <Text style={scoreValue}>{overallScore}/100</Text>
            <Text style={scoreLabel}>
              {overallScore >= 80 ? 'Excellent' : overallScore >= 60 ? 'Good' : overallScore >= 40 ? 'Needs Improvement' : 'Critical'}
            </Text>
          </Section>
          <Text style={scoreDescription}>
            {overallScore >= 80 
              ? 'Your site has strong SEO fundamentals with room for optimization.'
              : overallScore >= 60 
              ? 'Solid foundation with several opportunities for improvement.'
              : overallScore >= 40
              ? 'Multiple areas need attention to improve search performance.'
              : 'Immediate action required to address critical SEO issues.'
            }
          </Text>
        </Section>

        <Section style={issuesSection}>
          <Text style={issuesTitle}>Issues Discovered</Text>
          
          <Section style={issuesGrid}>
            <Section style={issueCard}>
              <Text style={issueIcon}>🚨</Text>
              <Text style={issueValue}>{criticalIssues}</Text>
              <Text style={issueLabel}>Critical Issues</Text>
              <Text style={issueDesc}>Immediate fixes needed</Text>
            </Section>

            <Section style={issueCard}>
              <Text style={issueIcon}>⚠️</Text>
              <Text style={issueValue}>{warningIssues}</Text>
              <Text style={issueLabel}>Warnings</Text>
              <Text style={issueDesc}>Should be addressed</Text>
            </Section>

            <Section style={issueCard}>
              <Text style={issueIcon}>💡</Text>
              <Text style={issueValue}>{opportunitiesFound}</Text>
              <Text style={issueLabel}>Opportunities</Text>
              <Text style={issueDesc}>Growth potential</Text>
            </Section>
          </Section>
        </Section>

        <Section style={findingsSection}>
          <Text style={findingsTitle}>Key Findings & Opportunities</Text>
          
          <Section style={findingItem}>
            <Text style={findingIcon}>🎯</Text>
            <div>
              <Text style={findingTitle}>Top Keyword Opportunity</Text>
              <Text style={findingDesc}>"{topKeywordOpportunity}" - 2,400 monthly searches, low competition</Text>
            </div>
          </Section>

          <Section style={findingItem}>
            <Text style={findingIcon}>⚡</Text>
            <div>
              <Text style={findingTitle}>Page Speed Optimization</Text>
              <Text style={findingDesc}>Average load time: 4.2s - Potential 35% improvement identified</Text>
            </div>
          </Section>

          <Section style={findingItem}>
            <Text style={findingIcon}>📱</Text>
            <div>
              <Text style={findingTitle}>Mobile Optimization</Text>
              <Text style={findingDesc}>Core Web Vitals need improvement - 3 critical mobile issues found</Text>
            </div>
          </Section>

          <Section style={findingItem}>
            <Text style={findingIcon}>🔗</Text>
            <div>
              <Text style={findingTitle}>Link Building Potential</Text>
              <Text style={findingDesc}>12 high-authority sites identified for outreach opportunities</Text>
            </div>
          </Section>

          <Section style={findingItem}>
            <Text style={findingIcon}>📝</Text>
            <div>
              <Text style={findingTitle}>Content Gaps</Text>
              <Text style={findingDesc}>18 high-value topics your competitors rank for but you don't</Text>
            </div>
          </Section>
        </Section>

        <Section style={categoriesSection}>
          <Text style={categoriesTitle}>Audit Categories Analyzed</Text>
          
          <Section style={categoryGrid}>
            <Section style={categoryItem}>
              <Text style={categoryIcon}>🏗️</Text>
              <Text style={categoryName}>Technical SEO</Text>
              <Text style={categoryScore}>68/100</Text>
            </Section>

            <Section style={categoryItem}>
              <Text style={categoryIcon}>📝</Text>
              <Text style={categoryName}>Content Quality</Text>
              <Text style={categoryScore}>75/100</Text>
            </Section>

            <Section style={categoryItem}>
              <Text style={categoryIcon}>🔗</Text>
              <Text style={categoryName}>Link Profile</Text>
              <Text style={categoryScore}>71/100</Text>
            </Section>

            <Section style={categoryItem}>
              <Text style={categoryIcon}>📱</Text>
              <Text style={categoryName}>User Experience</Text>
              <Text style={categoryScore}>64/100</Text>
            </Section>
          </Section>
        </Section>

        <Section style={buttonContainer}>
          <Button style={button} href="https://rootliftdigital.com/seo-audit-report">
            Download Full Report
          </Button>
        </Section>

        <Section style={nextStepsSection}>
          <Text style={nextStepsTitle}>Recommended Action Plan:</Text>
          <Text style={nextStep}>🚨 Phase 1: Fix critical technical issues (Week 1-2)</Text>
          <Text style={nextStep}>📝 Phase 2: Optimize existing content and meta tags (Week 3-4)</Text>
          <Text style={nextStep}>🎯 Phase 3: Target new keyword opportunities (Month 2)</Text>
          <Text style={nextStep}>🔗 Phase 4: Execute link building strategy (Month 2-3)</Text>
          <Text style={nextStep}>📊 Phase 5: Monitor and refine based on results (Ongoing)</Text>
        </Section>

        <Section style={impactSection}>
          <Text style={impactTitle}>Projected Impact</Text>
          <Text style={impactText}>
            Based on our analysis, implementing these recommendations could result in:
          </Text>
          <Text style={impactMetric}>📈 25-40% increase in organic traffic within 3-6 months</Text>
          <Text style={impactMetric}>🎯 Ranking improvements for 15+ target keywords</Text>
          <Text style={impactMetric">⚡ 35% faster page load times</Text>
          <Text style={impactMetric">📱 Improved mobile user experience scores</Text>
        </Section>

        <Text style={text}>
          Ready to implement these improvements? Let's schedule a{' '}
          <Link href="https://calendly.com/rootliftdigital/seo-strategy" style={link}>
            strategy consultation
          </Link>{' '}
          to discuss your SEO roadmap.
        </Text>

        <Text style={text}>
          Questions about your audit results?{' '}
          <Link href="mailto:seo@rootliftdigital.com" style={link}>
            seo@rootliftdigital.com
          </Link>
        </Text>

        <Text style={text}>
          Ready to boost your search rankings!
          <br />
          The Rootlift Digital SEO Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default SEOAuditCompleteEmail;

const main = {
  backgroundColor: '#ffffff',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};

const container = {
  margin: '0 auto',
  padding: '20px 0 48px',
  maxWidth: '560px',
};

const logoContainer = {
  marginTop: '32px',
  textAlign: 'center' as const,
};

const logo = {
  margin: '0 auto',
};

const headerBanner = {
  textAlign: 'center' as const,
  margin: '40px 0 20px 0',
  padding: '24px',
  backgroundColor: '#f0fdf4',
  borderRadius: '8px',
  border: '1px solid #22c55e',
};

const headerIcon = {
  fontSize: '48px',
  margin: '0 0 16px 0',
};

const h1 = {
  color: '#e11d48',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
  padding: '0',
};

const websiteText = {
  color: '#6b7280',
  fontSize: '16px',
  fontWeight: '500',
  margin: '0',
};

const heroText = {
  color: '#374151',
  fontSize: '16px',
  lineHeight: '24px',
  margin: '24px 0',
};

const scoreSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  border: '1px solid #fecaca',
  textAlign: 'center' as const,
};

const scoreTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
};

const scoreDisplay = {
  margin: '16px 0',
};

const scoreValue = {
  color: '#e11d48',
  fontSize: '48px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
};

const scoreLabel = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: '600',
  margin: '0',
};

const scoreDescription = {
  color: '#6b7280',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '16px 0 0 0',
};

const issuesSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
};

const issuesTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 24px 0',
  textAlign: 'center' as const,
};

const issuesGrid = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: '12px',
};

const issueCard = {
  textAlign: 'center' as const,
  padding: '16px 8px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const issueIcon = {
  fontSize: '24px',
  margin: '0 0 8px 0',
};

const issueValue = {
  color: '#1f2937',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const issueLabel = {
  color: '#374151',
  fontSize: '12px',
  fontWeight: '600',
  margin: '0 0 4px 0',
};

const issueDesc = {
  color: '#6b7280',
  fontSize: '10px',
  margin: '0',
};

const findingsSection = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#ecfdf5',
  borderRadius: '8px',
  border: '1px solid #10b981',
};

const findingsTitle = {
  color: '#1f2937',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
  textAlign: 'center' as const,
};

const findingItem = {
  display: 'flex',
  alignItems: 'flex-start',
  margin: '16px 0',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '6px',
  border: '1px solid #e5e7eb',
};

const findingIcon = {
  fontSize: '20px',
  marginRight: '12px',
  flexShrink: 0,
};

const findingTitle = {
  color: '#1f2937',
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '0 0 4px 0',
};

const findingDesc = {
  color: '#6b7280',
  fontSize: '13px',
  lineHeight: '18px',
  margin: '0',
};

const categoriesSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  border: '1px solid #f59e0b',
};

const categoriesTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
  textAlign: 'center' as const,
};

const categoryGrid = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '12px',
};

const categoryItem = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '12px',
  backgroundColor: '#ffffff',
  borderRadius: '4px',
};

const categoryIcon = {
  fontSize: '16px',
  marginRight: '8px',
};

const categoryName = {
  color: '#1f2937',
  fontSize: '12px',
  fontWeight: '600',
  flex: 1,
};

const categoryScore = {
  color: '#059669',
  fontSize: '12px',
  fontWeight: 'bold',
};

const buttonContainer = {
  margin: '32px auto',
  width: 'auto',
  textAlign: 'center' as const,
};

const button = {
  backgroundColor: '#e11d48',
  borderRadius: '6px',
  fontWeight: '600',
  color: '#fff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '12px 24px',
};

const nextStepsSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f0f9ff',
  borderRadius: '8px',
  border: '1px solid #0ea5e9',
};

const nextStepsTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 16px 0',
};

const nextStep = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '20px',
  margin: '8px 0',
};

const impactSection = {
  margin: '32px 0',
  padding: '20px',
  backgroundColor: '#f8fafc',
  borderRadius: '8px',
  textAlign: 'center' as const,
};

const impactTitle = {
  color: '#1f2937',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 12px 0',
};

const impactText = {
  color: '#374151',
  fontSize: '14px',
  margin: '0 0 16px 0',
};

const impactMetric = {
  color: '#059669',
  fontSize: '14px',
  fontWeight: '600',
  margin: '6px 0',
};

const text = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '24px',
  margin: '16px 0',
};

const link = {
  color: '#e11d48',
  textDecoration: 'underline',
};